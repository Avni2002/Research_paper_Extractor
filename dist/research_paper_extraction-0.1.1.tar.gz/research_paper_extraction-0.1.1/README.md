# Research Paper Extraction  
This project fetches research papers from PubMed and extracts details of non-academic authors.  
