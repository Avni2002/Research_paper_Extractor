from research_paper_extraction.pubmed_fetch import main

if __name__ == "__main__":
    main()
